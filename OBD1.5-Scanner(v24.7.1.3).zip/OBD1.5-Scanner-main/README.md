<div align="center">
 
 <p align="center">** BETA-PROJECT ** May be Glitchy with Discrepancies in the Results. **
<br/><img width="64" src='https://github.com/Toremetal/OBD1.5-Scanner/assets/95604373/48fdd46a-8a97-48bb-a80e-4bf3f295ee02'/>
<br/>Web-Based Project for reading diagnostic data from OBD 1.5 ECMs installed in the 94/95 Camaro Vin S 3.4L
<br/> No install Required. Works with most USB-port-connection compatible devices. Windows, Chrome Book, etc.
<br/> Click the link and connect your USB cable to your device and the car's OBD connector.
<br/>
  https://toremetal.com/OBD1.5-Scanner
<br/><img src='https://github.com/Toremetal/OBD1.5-Scanner/assets/95604373/49ab1a04-93d2-41cc-8341-550e36890f0f'/>
<br/><sub>( Download <a target="_blank" and rel="noopener noreferrer" href='https://github.com/Toremetal/OBD1.5-Scanner/archive/refs/heads/main.zip' download='OBD1.5-Scanner'>OBD1.5-Scanner-main.zip</a> to use off-line )</sub>
 </p>
 
 <!--<img src='https://github.com/Toremetal/OBD1.5-Scanner/assets/95604373/356b540d-90ee-4d64-ba7d-ce83bc5a74c8'/>-->
<p align="center">     ***************************************************************************************
<br/>                                    ™T©ReMeTaL Technology.
<br/>                             Technology, Software, and Solutions.
<br/>                              visit us at https://toremetal.com
<br/>                             Copyright (C) ©2024™T©ReMeTaL.
<br/>                             Computer Scientist: (David W. Rick).
<br/>     **************************************************************************************
</p>
</div>
